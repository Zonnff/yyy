# SEXY-EVIL-TWIN : Makes Evil Twin Attack More Sexy

# How it works

1.Scan the networks.

2.Select network.

3.Capture handshake (can be used without handshake)

4.We choose one of several web interfaces tailored for me (thanks to the collaboration of the users)

5.Mounts one FakeAP imitating the original

6.A DHCP server is created on FakeAP

7.It creates a DNS server to redirect all requests to the Host

8.The web server with the selected interface is launched

9.The mechanism is launched to check the validity of the passwords that will be introduced

10.It deauthentificate all users of the network, hoping to connect to FakeAP and enter the password.

11.The attack will stop after the correct password checking

# Features

* Compatible with wifislax, kali linux, parrotOS and more
* Capture handshake (can be used without handshake)
* choose one of several web interfaces tailored for you (thanks to the collaboration of the users)
* Mounts one FakeAP imitating the original
* It creates a DNS server to redirect all requests to the Host
* The web server with the selected interface is launched
* The mechanism is launched to check the validity of the passwords is introduced
* It deauthentificate all users of the network, hoping to connect to FakeAP and enter the password.
* The attack will stop after the correct password checking
* Available 13 language (English, Arabic, Spanish, Indonesian, Turkish, Russian, German, Chinese, Polish, Italian, Hebrew, Thai, Norwegian)
* Available 25 router login page (scama)

# Requirements

* Aircrack-ng
* Aireplay-ng
* Airmon-ng
* Airodump-ng
* Awk
* Curl
* Dhcpd
* Hostapd
* Iwconfig
* Lighttpd
* Macchanger
* Mdk3
* Php5-cgi
* Pyrit
* Python
* Unzip
* Xterm

# How to use

```
$ git clone https://github.com/roobini-gamer/SEXY-EVIL-TWIN.git

$ cd SEXY-EVIL-TWIN-master

$ chmod +x SEXY-EVIL-TWIN

$ bash SEXY-EVIL-TWIN
```

# My web site

<a href="https://bit.ly/3llxWWO">CLICK HERE!</a>
