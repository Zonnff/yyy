var data_language = {
	innerHTML : {
		DIV_UserName : 'UserName',
		DIV_Password : 'Password',
		DIV_Lang : 'Language'
	},
	value : {
		uipostSubmit : 'Login',
		Reset : 'Reset'
	}
}